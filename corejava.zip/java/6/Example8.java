import java.util.*;
public class Example8
 {
  public static void main(String[]  args)
   {
    HashSet<String> list=new HashSet<String>();
    list.add("Ankit");
    list.add("Karuna");
    list.add("Nitin");
    list.add("Naman");
    list.add("Deepak");
    list.add("Swati");
    System.out.print("Original hash set is  : ");
    System.out.println(list);
    System.out.println("Now Size of Hash Set is : "+list.size());
   }
 }
