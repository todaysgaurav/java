/* Write a Java program to display the asterisk
pattern as shown below (Without using loop):
*****
*****
*****
*****
*/
import java.io.*;
import java.net.*;
public class Pattern
{
  public static void main(String args[])
   {
     System.out.println("*****");
     System.out.println("*****");
     System.out.println("*****");
     System.out.println("*****");
   }
}
