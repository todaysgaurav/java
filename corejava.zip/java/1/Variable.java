/*Write a Java program to declare two integer variables,
one float variable, and one string variable and assign 10, 12.5,
and "Java programming" to them respectively. Then display their
values on the screen.
*/
import java.io.*;
import java.net.*;
public class Variable
{
 public static void main(String args[])
  {
   int i1;
   float f1;
   String str;
   i1=10;
   f1=12.5f;
   str="Java programming";
   System.out.println(i1);
   System.out.println(f1);
   System.out.println(str);
   
  }
}
