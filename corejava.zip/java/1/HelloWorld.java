/*Write a Java program to display Hello World on
the screen.
*/
import java.io.*;
import java.net.*;
public class HelloWorld
{
 public static void main(String args[])
  {
   System.out.println("Hello World");
  }
}
